//
//  NSBundle+CPCAdditions.h
//  CorePaymentCard
//
//  Created by Michael White on 1/8/13.
//  Copyright (c) 2013 Square, Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSBundle (CPCAdditions)

+ (NSBundle *)corePaymentCardResourcesBundle;

@end
