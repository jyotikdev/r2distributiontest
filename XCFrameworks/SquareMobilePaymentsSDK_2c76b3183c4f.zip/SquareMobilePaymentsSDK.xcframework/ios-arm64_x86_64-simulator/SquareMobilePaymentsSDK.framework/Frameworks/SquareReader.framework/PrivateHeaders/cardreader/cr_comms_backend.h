// Copyright (c) 2015 Square, Inc. All rights reserved.

#pragma once

typedef enum
{
    CR_COMMS_BACKEND_RESULT_SUCCESS,
    CR_COMMS_BACKEND_RESULT_INVALID_PARAMETER,
    CR_COMMS_BACKEND_RESULT_UNKNOWN_ERROR,
} cr_comms_backend_result_t;
